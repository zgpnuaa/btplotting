#!/usr/bin/env python
# -*- coding: utf-8 -*-
""" ib.ext.cfg.TickType -> config module for TickType.java.

"""
