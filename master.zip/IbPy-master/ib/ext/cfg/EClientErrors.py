#!/usr/bin/env python
# -*- coding: utf-8 -*-
""" ib.ext.cfg.EClientErrors -> config module for EClientErrors.java.

"""
