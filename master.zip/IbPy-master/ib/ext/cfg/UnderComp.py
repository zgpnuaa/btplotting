#!/usr/bin/env python
# -*- coding: utf-8 -*-
""" ib.ext.cfg.UnderComp -> config module for UnderComp.java.

"""
