#!/usr/bin/env python
# -*- coding: utf-8 -*-
""" ib.ext.cfg.MarketDataType -> config module for MarketDataType.java.

"""
