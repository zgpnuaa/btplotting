# v0.8.0

* Some internal reorganization
* Made available as IbPy2 in PyPI

# Pre v0.8.0

* TWS API version 9.70 now supported
* Over 60% test coverage and growing
* Fixed outstanding bugs in EReader generated source
* Module ib.opt.logger moved to ib.lib.logger
* Class ib.opt.Connection moved to new ib.opt.connection module
* Added script to filter TWS log files; see `demo/log_filter`
* Added ib.sym package to hold various symbolic constants
* Many small enhancements to ib.opt package